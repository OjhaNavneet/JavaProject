package entity;


public class Cd extends Product{

	public Cd(String productName, int noOfItems, double price) {
		super(productName, noOfItems, price,10);
		// TODO Auto-generated constructor stub
	}
	

}
