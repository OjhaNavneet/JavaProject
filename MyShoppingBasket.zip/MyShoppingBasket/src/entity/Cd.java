package entity;


public class Cd extends Product{

	public Cd(int productId,String productName, int noOfItems, double price) {
		super(productId,productName, noOfItems, price,10);
		// TODO Auto-generated constructor stub
	}
	

}
