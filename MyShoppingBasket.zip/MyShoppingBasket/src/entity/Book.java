package entity;




public class Book extends Product {

	public Book(String productName, int noOfItems, double price) {
		super(productName, noOfItems, price,0);
		// TODO Auto-generated constructor stub
	}
	
	
}
