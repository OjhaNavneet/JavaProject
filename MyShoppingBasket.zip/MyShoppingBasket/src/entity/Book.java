package entity;




public class Book extends Product {

	public Book(int productId,String productName, int noOfItems, double price) {
		super(productId,productName, noOfItems, price,0);
		// TODO Auto-generated constructor stub
	}
	
	
}
