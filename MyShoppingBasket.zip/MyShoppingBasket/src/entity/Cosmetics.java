package entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


public class Cosmetics extends Product {

	public Cosmetics(String productName, int noOfItems, double price) {
		super(productName, noOfItems, price,12 );
		// TODO Auto-generated constructor stub
	}
	
	
	


}
